import React, { Suspense, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, ContactShadows, Decal, Html } from '@react-three/drei';
import * as THREE from 'three';
import { Upload, RotateCcw, Save, Download, Layers, Palette, Type, Shapes, Image as ImageIcon, Brush, Sparkles } from 'lucide-react';
import './styles.css';

const shoeTypes = [
  { id: 'low-top', name: 'Low Top Sneaker', scale: [2.8, 0.85, 1.05], sole: [2.95, 0.22, 1.12] },
  { id: 'high-top', name: 'High Top Sneaker', scale: [2.65, 1.25, 1.0], sole: [2.9, 0.22, 1.1] },
  { id: 'boot', name: 'Boot', scale: [2.7, 1.45, 1.08], sole: [3.05, 0.3, 1.16] },
  { id: 'slide', name: 'Slide', scale: [2.55, 0.48, 1.08], sole: [2.75, 0.22, 1.14] }
];

const tools = [
  { id: 'brush', label: 'Brush', icon: Brush },
  { id: 'shape', label: 'Shapes', icon: Shapes },
  { id: 'text', label: 'Text', icon: Type },
  { id: 'image', label: 'Image', icon: ImageIcon },
  { id: 'layers', label: 'Layers', icon: Layers }
];

function ShoeModel({ shoe, baseColor, soleColor, accentColor, decalTexture, activeTool }) {
  const group = useRef();
  const upperMaterial = useMemo(() => new THREE.MeshStandardMaterial({ color: baseColor, roughness: 0.52, metalness: 0.04 }), [baseColor]);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.05;
  });

  return (
    <group ref={group} position={[0, 0.12, 0]}>
      <mesh position={[0, 0.5, 0]} scale={shoe.scale} castShadow receiveShadow>
        <sphereGeometry args={[0.5, 80, 40]} />
        <primitive object={upperMaterial} attach="material" />
        {decalTexture && <Decal position={[0.55, 0.15, 0.48]} rotation={[0, 0, 0]} scale={[0.58, 0.35, 0.58]} map={decalTexture} />}
      </mesh>
      <mesh position={[0.1, 0.05, 0]} scale={shoe.sole} castShadow receiveShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={soleColor} roughness={0.76} />
      </mesh>
      <mesh position={[-0.72, 0.58, 0.5]} scale={[0.55, 0.08, 0.06]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={accentColor} />
      </mesh>
      <mesh position={[-0.15, 0.72, 0.47]} rotation={[0.1, 0, 0]} scale={[0.95, 0.07, 0.05]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={accentColor} />
      </mesh>
      {activeTool === 'shape' && (
        <mesh position={[0.7, 0.55, 0.52]} scale={[0.16, 0.16, 0.04]} castShadow>
          <circleGeometry args={[1, 48]} />
          <meshStandardMaterial color={accentColor} />
        </mesh>
      )}
    </group>
  );
}

function App() {
  const [shoeId, setShoeId] = useState('low-top');
  const [activeTool, setActiveTool] = useState('brush');
  const [baseColor, setBaseColor] = useState('#f7f3ea');
  const [soleColor, setSoleColor] = useState('#161616');
  const [accentColor, setAccentColor] = useState('#ff3b30');
  const [decalTexture, setDecalTexture] = useState(null);
  const [layers, setLayers] = useState(['Base upper', 'Sole', 'Accent marks']);
  const [status, setStatus] = useState('Ready');
  const shoe = shoeTypes.find(s => s.id === shoeId) || shoeTypes[0];

  function uploadLogo(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    new THREE.TextureLoader().load(url, texture => {
      texture.colorSpace = THREE.SRGBColorSpace;
      setDecalTexture(texture);
      setActiveTool('image');
      setLayers(prev => [file.name, ...prev]);
      setStatus('Image placed on shoe');
    });
  }

  function saveProject() {
    const project = { shoeId, baseColor, soleColor, accentColor, layers, savedAt: new Date().toISOString() };
    localStorage.setItem('shoelab-project', JSON.stringify(project));
    setStatus('Saved on this phone/browser');
  }

  function resetDesign() {
    setBaseColor('#f7f3ea');
    setSoleColor('#161616');
    setAccentColor('#ff3b30');
    setDecalTexture(null);
    setLayers(['Base upper', 'Sole', 'Accent marks']);
    setStatus('Design reset');
  }

  function exportMockup() {
    setStatus('Export button wired for next build');
    alert('Next build will export a PNG mockup from the 3D canvas. This prototype proves the 3D designer flow first.');
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div>
          <h1>ShoeLab 3D</h1>
          <p>Phone-first custom shoe designer</p>
        </div>
        <span className="status"><Sparkles size={14} /> {status}</span>
      </header>

      <main className="layout">
        <section className="panel left-panel">
          <h2>1. Pick shoe</h2>
          <div className="shoe-grid">
            {shoeTypes.map(item => (
              <button key={item.id} className={shoeId === item.id ? 'active' : ''} onClick={() => setShoeId(item.id)}>{item.name}</button>
            ))}
          </div>
          <h2>2. Tools</h2>
          <div className="tool-grid">
            {tools.map(tool => {
              const Icon = tool.icon;
              return <button key={tool.id} className={activeTool === tool.id ? 'active' : ''} onClick={() => setActiveTool(tool.id)}><Icon size={18} />{tool.label}</button>;
            })}
          </div>
        </section>

        <section className="viewer">
          <div className="viewer-badge">{shoe.name}</div>
          <Canvas camera={{ position: [4, 2.1, 4], fov: 42 }} shadows gl={{ preserveDrawingBuffer: true }}>
            <ambientLight intensity={0.65} />
            <directionalLight position={[4, 5, 3]} intensity={2.2} castShadow />
            <Suspense fallback={<Html center>Loading shoe...</Html>}>
              <ShoeModel shoe={shoe} baseColor={baseColor} soleColor={soleColor} accentColor={accentColor} decalTexture={decalTexture} activeTool={activeTool} />
              <Environment preset="city" />
              <ContactShadows position={[0, -0.08, 0]} opacity={0.45} scale={8} blur={2.5} />
            </Suspense>
            <OrbitControls enablePan={false} minDistance={3} maxDistance={7} />
          </Canvas>
        </section>

        <section className="panel right-panel">
          <h2><Palette size={17}/> Art palette</h2>
          <label>Upper color<input type="color" value={baseColor} onChange={e => setBaseColor(e.target.value)} /></label>
          <label>Sole color<input type="color" value={soleColor} onChange={e => setSoleColor(e.target.value)} /></label>
          <label>Accent/highlight<input type="color" value={accentColor} onChange={e => setAccentColor(e.target.value)} /></label>
          <label className="upload"><Upload size={16}/> Upload logo/image<input type="file" accept="image/*" onChange={uploadLogo} /></label>

          <h2><Layers size={17}/> Layers</h2>
          <div className="layers">{layers.map((layer, i) => <div key={`${layer}-${i}`}><span>{layer}</span><small>visible</small></div>)}</div>

          <div className="actions">
            <button onClick={resetDesign}><RotateCcw size={16}/>Reset</button>
            <button onClick={saveProject}><Save size={16}/>Save</button>
            <button className="wide" onClick={exportMockup}><Download size={16}/>Export Mockup</button>
          </div>
        </section>
      </main>
    </div>
  );
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
}

createRoot(document.getElementById('root')).render(<App />);
