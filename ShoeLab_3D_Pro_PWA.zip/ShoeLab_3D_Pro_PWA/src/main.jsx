import React, { Suspense, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment, ContactShadows, Decal, Html } from '@react-three/drei';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as THREE from 'three';
import {
  Upload, RotateCcw, Save, Download, Layers, Palette, Type, Shapes,
  Image as ImageIcon, Sparkles, Box, Eye, EyeOff, Undo2, Redo2,
  Paintbrush, BadgeCheck, Camera, Shirt, Wand2
} from 'lucide-react';
import './styles.css';

const shoeTemplates = [
  { id: 'runner', name: 'Performance Runner', vibe: 'fast / lightweight', scale: [2.9, 0.82, 1.02], sole: [3.08, 0.25, 1.12] },
  { id: 'court', name: 'Court Low', vibe: 'clean / lifestyle', scale: [2.75, 0.9, 1.05], sole: [2.95, 0.25, 1.15] },
  { id: 'high', name: 'High Top', vibe: 'basketball / street', scale: [2.65, 1.32, 1.02], sole: [2.95, 0.27, 1.12] },
  { id: 'boot', name: 'Trail Boot', vibe: 'rugged / outdoor', scale: [2.72, 1.45, 1.08], sole: [3.1, 0.34, 1.18] }
];

const zones = [
  { id: 'upper', name: 'Upper', default: '#f4f0e8' },
  { id: 'sole', name: 'Midsole / Outsole', default: '#171717' },
  { id: 'accent', name: 'Accent / Swoop', default: '#ff3b30' },
  { id: 'lining', name: 'Collar / Lining', default: '#0f172a' },
  { id: 'laces', name: 'Laces', default: '#fafafa' }
];

const tools = [
  { id: 'paint', label: 'Paint', icon: Paintbrush },
  { id: 'image', label: 'Logo', icon: ImageIcon },
  { id: 'shape', label: 'Shapes', icon: Shapes },
  { id: 'text', label: 'Text', icon: Type },
  { id: 'material', label: 'Material', icon: Shirt },
  { id: 'ai', label: 'Style AI', icon: Wand2 }
];

const materials = [
  { id: 'matte', name: 'Matte leather', roughness: 0.72, metalness: 0.02 },
  { id: 'gloss', name: 'Gloss patent', roughness: 0.18, metalness: 0.04 },
  { id: 'mesh', name: 'Sport mesh', roughness: 0.92, metalness: 0.0 },
  { id: 'suede', name: 'Soft suede', roughness: 0.98, metalness: 0.0 }
];

function uid() {
  return globalThis.crypto?.randomUUID?.() || String(Date.now() + Math.random());
}

function UploadedGLBShoe({ url, zoneColors, materialMode }) {
  const [scene, setScene] = useState(null);
  const group = useRef();

  useEffect(() => {
    if (!url) return;
    const loader = new GLTFLoader();
    loader.load(url, (gltf) => {
      const cloned = gltf.scene.clone(true);
      cloned.traverse((child) => {
        if (!child.isMesh) return;
        child.castShadow = true;
        child.receiveShadow = true;
        const name = child.name.toLowerCase();
        const zone = name.includes('sole') || name.includes('outsole') || name.includes('midsole')
          ? 'sole'
          : name.includes('lace')
          ? 'laces'
          : name.includes('lining') || name.includes('collar')
          ? 'lining'
          : name.includes('accent') || name.includes('logo') || name.includes('swoosh')
          ? 'accent'
          : 'upper';

        child.material = new THREE.MeshStandardMaterial({
          color: zoneColors[zone],
          roughness: materialMode.roughness,
          metalness: materialMode.metalness
        });
      });
      setScene(cloned);
    });
  }, [url, zoneColors, materialMode]);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.025;
  });

  if (!scene) return <Html center>Loading uploaded 3D shoe...</Html>;

  return <group ref={group} scale={1.8} position={[0, -0.55, 0]}><primitive object={scene} /></group>;
}

function ProceduralShoe({ template, zoneColors, materialMode, decalTexture, selectedZone, showDemoArt }) {
  const group = useRef();
  useFrame((_, delta) => { if (group.current) group.current.rotation.y += delta * 0.035; });

  const materialFor = (zone) => new THREE.MeshStandardMaterial({
    color: zoneColors[zone],
    roughness: materialMode.roughness,
    metalness: materialMode.metalness,
    emissive: selectedZone === zone ? new THREE.Color(zoneColors[zone]).multiplyScalar(0.12) : new THREE.Color('#000000')
  });

  return (
    <group ref={group} position={[0, 0.1, 0]}>
      <mesh position={[0, 0.52, 0]} scale={template.scale} castShadow receiveShadow>
        <sphereGeometry args={[0.5, 96, 48]} />
        <primitive object={materialFor('upper')} attach="material" />
        {decalTexture && <Decal position={[0.62, 0.15, 0.49]} rotation={[0, 0, 0]} scale={[0.58, 0.36, 0.58]} map={decalTexture} />}
      </mesh>

      <mesh position={[0.08, 0.05, 0]} scale={template.sole} castShadow receiveShadow>
        <boxGeometry args={[1, 1, 1]} />
        <primitive object={materialFor('sole')} attach="material" />
      </mesh>

      <mesh position={[-0.72, 0.6, 0.51]} scale={[0.62, 0.08, 0.065]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <primitive object={materialFor('accent')} attach="material" />
      </mesh>

      <mesh position={[-0.14, 0.75, 0.49]} rotation={[0.1, 0, 0]} scale={[1.02, 0.07, 0.05]} castShadow>
        <boxGeometry args={[1, 1, 1]} />
        <primitive object={materialFor('laces')} attach="material" />
      </mesh>

      <mesh position={[-0.62, 0.85, 0]} scale={[0.72, 0.2, 0.82]} castShadow>
        <torusGeometry args={[0.35, 0.05, 20, 64]} />
        <primitive object={materialFor('lining')} attach="material" />
      </mesh>

      {showDemoArt && <>
        <mesh position={[0.74, 0.57, 0.53]} scale={[0.16, 0.16, 0.04]} castShadow>
          <circleGeometry args={[1, 64]} /><meshStandardMaterial color={zoneColors.accent} />
        </mesh>
        <mesh position={[0.28, 0.32, 0.54]} rotation={[0, 0, -0.25]} scale={[0.55, 0.045, 0.045]} castShadow>
          <boxGeometry args={[1, 1, 1]} /><meshStandardMaterial color="#ffffff" />
        </mesh>
      </>}
    </group>
  );
}

function App() {
  const [templateId, setTemplateId] = useState('runner');
  const [activeTool, setActiveTool] = useState('paint');
  const [selectedZone, setSelectedZone] = useState('upper');
  const [materialId, setMaterialId] = useState('matte');
  const [uploadedModelUrl, setUploadedModelUrl] = useState(null);
  const [decalTexture, setDecalTexture] = useState(null);
  const [showDemoArt, setShowDemoArt] = useState(true);
  const [projectName, setProjectName] = useState('Untitled Colorway 001');
  const [status, setStatus] = useState('Ready for design');
  const [zoneColors, setZoneColors] = useState(() => Object.fromEntries(zones.map(z => [z.id, z.default])));
  const [layers, setLayers] = useState([
    { id: 'base', name: 'Base colorway', visible: true, locked: false },
    { id: 'demo', name: 'Demo art marks', visible: true, locked: false },
    { id: 'model', name: '3D shoe model', visible: true, locked: true }
  ]);

  const template = shoeTemplates.find(s => s.id === templateId) || shoeTemplates[0];
  const materialMode = materials.find(m => m.id === materialId) || materials[0];

  function updateZoneColor(color) {
    setZoneColors(prev => ({ ...prev, [selectedZone]: color }));
    setStatus(`${zones.find(z => z.id === selectedZone)?.name} updated`);
  }

  function uploadGLB(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.glb') && !file.name.toLowerCase().endsWith('.gltf')) {
      setStatus('Use a .glb or .gltf shoe model');
      return;
    }
    setUploadedModelUrl(URL.createObjectURL(file));
    setLayers(prev => [{ id: uid(), name: file.name, visible: true, locked: false }, ...prev]);
    setStatus('Real 3D shoe model loaded');
  }

  function uploadLogo(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    new THREE.TextureLoader().load(url, (texture) => {
      texture.colorSpace = THREE.SRGBColorSpace;
      setDecalTexture(texture);
      setActiveTool('image');
      setLayers(prev => [{ id: uid(), name: `Logo: ${file.name}`, visible: true, locked: false }, ...prev]);
      setStatus('Logo/decal placed');
    });
  }

  function toggleLayer(id) {
    setLayers(prev => prev.map(layer => layer.id === id && !layer.locked ? { ...layer, visible: !layer.visible } : layer));
  }

  function resetDesign() {
    setZoneColors(Object.fromEntries(zones.map(z => [z.id, z.default])));
    setDecalTexture(null);
    setUploadedModelUrl(null);
    setShowDemoArt(true);
    setMaterialId('matte');
    setSelectedZone('upper');
    setLayers([
      { id: 'base', name: 'Base colorway', visible: true, locked: false },
      { id: 'demo', name: 'Demo art marks', visible: true, locked: false },
      { id: 'model', name: '3D shoe model', visible: true, locked: true }
    ]);
    setStatus('Design reset');
  }

  function saveProject() {
    const project = { projectName, templateId, selectedZone, materialId, zoneColors, layers, savedAt: new Date().toISOString() };
    localStorage.setItem('shoelab-pro-project', JSON.stringify(project));
    setStatus('Project saved on this device');
  }

  function exportSpec() {
    const spec = {
      brandApp: 'ShoeLab 3D Pro', projectName, shoeTemplate: template.name, material: materialMode.name,
      colorway: zoneColors, layers: layers.map(({ name, visible }) => ({ name, visible })),
      productionNotes: [
        'Final production requires UV-unwrapped GLB model.',
        'Each shoe zone should be named upper, sole, laces, lining, accent for automatic mapping.',
        'Artwork should export as texture maps and decal placement data in next build.'
      ]
    };
    const blob = new Blob([JSON.stringify(spec, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectName.replaceAll(' ', '_')}_shoelab_spec.json`;
    a.click();
    URL.revokeObjectURL(url);
    setStatus('Design spec exported');
  }

  return (
    <div className="app">
      <header className="topbar">
        <div>
          <div className="brand"><BadgeCheck size={20} /><h1>ShoeLab 3D Pro</h1></div>
          <p>Phone-first custom footwear design studio</p>
        </div>
        <div className="status"><Sparkles size={14} />{status}</div>
      </header>

      <div className="layout">
        <aside className="panel left-panel">
          <section className="card">
            <h2><Box size={16} />Shoe platform</h2>
            <input className="project-input" value={projectName} onChange={e => setProjectName(e.target.value)} />
            <div className="platform-list">
              {shoeTemplates.map(item => <button key={item.id} onClick={() => setTemplateId(item.id)} className={templateId === item.id ? 'selected' : ''}>
                <strong>{item.name}</strong><small>{item.vibe}</small>
              </button>)}
            </div>
            <label className="upload glb"><Upload size={16} />Upload real .GLB shoe<input type="file" accept=".glb,.gltf" onChange={uploadGLB} /></label>
          </section>

          <section className="card">
            <h2><Palette size={16} />Tool bench</h2>
            <div className="tool-grid">
              {tools.map(tool => { const Icon = tool.icon; return <button key={tool.id} onClick={() => setActiveTool(tool.id)} className={activeTool === tool.id ? 'selected' : ''}><Icon size={19} />{tool.label}</button>; })}
            </div>
            <div className="action-row"><button onClick={() => setStatus('Undo queued for next build')}><Undo2 size={16} />Undo</button><button onClick={() => setStatus('Redo queued for next build')}><Redo2 size={16} />Redo</button></div>
          </section>
        </aside>

        <main className="viewer">
          <div className="viewer-badge"><small>Live 3D preview</small><strong>{uploadedModelUrl ? 'Imported real model' : template.name}</strong></div>
          <div className="zone-strip">
            {zones.map(zone => <button key={zone.id} onClick={() => setSelectedZone(zone.id)} className={selectedZone === zone.id ? 'selected' : ''}><span style={{ background: zoneColors[zone.id] }} />{zone.name}</button>)}
          </div>
          <Canvas camera={{ position: [4.3, 2.2, 4.2], fov: 42 }} shadows gl={{ preserveDrawingBuffer: true }}>
            <ambientLight intensity={0.68} />
            <directionalLight position={[4, 5, 3]} intensity={2.4} castShadow />
            <Suspense fallback={<Html center>Loading studio...</Html>}>
              {uploadedModelUrl ? <UploadedGLBShoe url={uploadedModelUrl} zoneColors={zoneColors} materialMode={materialMode} /> : <ProceduralShoe template={template} zoneColors={zoneColors} materialMode={materialMode} decalTexture={decalTexture} selectedZone={selectedZone} showDemoArt={showDemoArt} />}
              <Environment preset="studio" />
              <ContactShadows position={[0, -0.08, 0]} opacity={0.5} scale={9} blur={2.8} />
            </Suspense>
            <OrbitControls enablePan={false} minDistance={3} maxDistance={7} />
          </Canvas>
        </main>

        <aside className="panel right-panel">
          <section className="card">
            <h2>Selected zone: {zones.find(z => z.id === selectedZone)?.name}</h2>
            <input className="color-picker" type="color" value={zoneColors[selectedZone]} onChange={e => updateZoneColor(e.target.value)} />
            <h2>Material finish</h2>
            <div className="material-grid">{materials.map(mat => <button key={mat.id} onClick={() => setMaterialId(mat.id)} className={materialId === mat.id ? 'selected' : ''}>{mat.name}</button>)}</div>
            <label className="upload artwork"><ImageIcon size={16} />Add logo / artwork<input type="file" accept="image/*" onChange={uploadLogo} /></label>
          </section>

          <section className="card">
            <h2><Layers size={16} />Design layers</h2>
            <div className="layers">{layers.map(layer => <button key={layer.id} onClick={() => toggleLayer(layer.id)}><span>{layer.name}</span>{layer.visible ? <Eye size={16} /> : <EyeOff size={16} />}</button>)}</div>
            <label className="checkbox"><input type="checkbox" checked={showDemoArt} onChange={e => setShowDemoArt(e.target.checked)} />Show demo art marks</label>
          </section>

          <div className="bottom-actions"><button onClick={resetDesign}><RotateCcw size={16} />Reset</button><button onClick={saveProject}><Save size={16} />Save</button><button className="wide" onClick={exportSpec}><Download size={16} />Export Design Spec</button><button className="wide secondary" onClick={() => setStatus('Mockup screenshot export is next build')}><Camera size={16} />Export Mockup PNG</button></div>
          <div className="truth">Real production requires UV-unwrapped shoe GLB files. This app is ready to accept them; generic geometry remains only as fallback.</div>
        </aside>
      </div>
    </div>
  );
}

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
}

createRoot(document.getElementById('root')).render(<App />);
