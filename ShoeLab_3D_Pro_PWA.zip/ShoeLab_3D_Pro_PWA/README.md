# ShoeLab 3D Pro PWA

Phone-first 3D shoe design studio prototype.

## Run locally

```bash
npm install
npm run dev
```

## Deploy

Use Vercel, Netlify, or GitHub Pages with HTTPS.

## Real 3D shoe models

Upload `.glb` or `.gltf` shoe models inside the app. For best results, name mesh parts:

- upper
- sole / midsole / outsole
- accent / logo / swoosh
- lining / collar
- laces

Final production needs UV-unwrapped GLB files for true artwork wrapping.
